// test/widget_test.dart
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_application_2/main.dart';

void main() {
  group('Todo App Tests', () {
    testWidgets('Add todo test', (WidgetTester tester) async {
      // Build our app and trigger a frame
      await tester.pumpWidget(const MyApp());

      // Verify that there are no todos initially
      expect(find.byType(ListTile), findsNothing);

      // Find the TextField and add button
      final textField = find.byType(TextField);
      final addButton = find.byIcon(Icons.add);

      // Enter text into TextField
      await tester.enterText(textField, 'Test Todo');
      await tester.pump();

      // Tap the add button
      await tester.tap(addButton);
      await tester.pump();

      // Verify that the todo was added
      expect(find.text('Test Todo'), findsOneWidget);
      expect(find.byType(ListTile), findsOneWidget);
      expect(find.byType(Checkbox), findsOneWidget);
    });

    testWidgets('Toggle todo completion test', (WidgetTester tester) async {
      // Build our app and trigger a frame
      await tester.pumpWidget(const MyApp());

      // Add a todo
      await tester.enterText(find.byType(TextField), 'Test Todo');
      await tester.tap(find.byIcon(Icons.add));
      await tester.pump();

      // Find the checkbox
      final checkbox = find.byType(Checkbox);
      
      // Verify initial state (unchecked)
      expect(tester.widget<Checkbox>(checkbox).value, false);

      // Tap the checkbox
      await tester.tap(checkbox);
      await tester.pump();

      // Verify the checkbox is now checked
      expect(tester.widget<Checkbox>(checkbox).value, true);
    });

    testWidgets('Tab navigation test', (WidgetTester tester) async {
      // Build our app and trigger a frame
      await tester.pumpWidget(const MyApp());

      // Verify all tabs are present
      expect(find.text('Stateful'), findsOneWidget);
      expect(find.text('Provider'), findsOneWidget);
      expect(find.text('Riverpod'), findsOneWidget);
      expect(find.text('Bloc'), findsOneWidget);
      expect(find.text('GetX'), findsOneWidget);

      // Test tab navigation
      await tester.tap(find.text('Provider'));
      await tester.pumpAndSettle();

      // Verify we're on the Provider tab (you can add specific Provider tab verification)
      expect(find.byType(ProviderTab), findsOneWidget);
    });

    testWidgets('Empty todo validation test', (WidgetTester tester) async {
      // Build our app and trigger a frame
      await tester.pumpWidget(const MyApp());

      // Try to add empty todo
      await tester.tap(find.byIcon(Icons.add));
      await tester.pump();

      // Verify that no todo was added
      expect(find.byType(ListTile), findsNothing);
    });
  });
}